//
//  ViewController.m
//  下载资料动画
//
//  Created by admin on 16/1/27.
//  Copyright © 2016年 admin. All rights reserved.
//

#import "ViewController.h"
#import "SQLDAnimationView.h"

@interface ViewController ()
@property(nonatomic,strong)SQLDAnimationView *loadingView;
@end

@implementation ViewController

-(SQLDAnimationView *)loadingView{
    if (!_loadingView) {
        _loadingView = [[SQLDAnimationView alloc]initWithFrame:CGRectMake(50, 100, 300, 300)];
        _loadingView.backgroundColor = [UIColor yellowColor];
        _loadingView.selfBackgroundColor = [UIColor redColor];
    }
    return _loadingView;
    
}
- (void)viewDidLoad {
    [super viewDidLoad];
    [self.view addSubview:self.loadingView];
    
    // Do any additional setup after loading the view, typically from a nib.
}

/**
 *  开始
 *
 */
- (IBAction)start:(id)sender {
    [self.loadingView loading];
}

/**
 *  停止中
 *
 */
- (IBAction)stop:(id)sender {
    [self.loadingView stop];
}

/**
 *  下载成功
 *
 */
- (IBAction)success:(id)sender {
    [self.loadingView loadingSuccessedCompletedBlock:^{
        NSLog(@"success");
    
    }];
}

/**
 *  下载失败
 *
 */
- (IBAction)fail:(id)sender {
    [self.loadingView loadingFailedCompletedBlock:^{
        NSLog(@"fail");
    }];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
